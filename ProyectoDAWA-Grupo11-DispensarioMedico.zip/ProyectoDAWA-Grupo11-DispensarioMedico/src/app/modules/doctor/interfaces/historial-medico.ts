export interface HistorialMedico { 
    idPaciente:     number
    idMedico:       number
    fechaVisita:    number
    sintomas:       string
    diagnostico:    string
    tratamiento:    string
    receta:         string
}
