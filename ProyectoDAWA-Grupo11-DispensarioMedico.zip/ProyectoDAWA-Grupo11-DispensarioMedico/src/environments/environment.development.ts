export const environment = {
    production: true,
    endpoint: "assets/data/"
};
